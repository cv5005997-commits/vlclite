# VLC Lite (reconstrucción inicial)

Proyecto Android nativo Kotlin con una interfaz mínima y LibVLC como único motor multimedia.

## Objetivos
- Android TV y teléfonos con una UI nativa liviana.
- Reproducción directa HTTP/HTTPS y HLS (M3U8) mediante LibVLC.
- Sin Media3/ExoPlayer ni frameworks visuales pesados.
- Parámetros iniciales conservadores para caché y decodificación.

## Compilar
Requiere JDK 17 y Android SDK Platform 35. Abrir la carpeta en Android Studio y ejecutar:
`./gradlew assembleDebug` o `./gradlew assembleRelease`.

## Estado real
Este ZIP contiene código fuente inicial, NO una APK compilada ni una réplica completa de todas las funciones de VLC.
No se ejecutó una compilación en este entorno. La compatibilidad real, el uso de RAM/CPU y la reproducción de cada stream deben medirse en los dispositivos objetivo.

## Próximas tareas técnicas
1. Validar que la versión LibVLC indicada resuelva desde Maven Central.
2. Añadir selector de archivos, parser M3U/M3U8, lista de canales y favoritos.
3. Añadir cabeceras HTTP configurables, User-Agent, cookies y redirecciones.
4. Medir RAM/CPU en TV de 1 GB y móvil; ajustar caché y decodificador por dispositivo.
5. Probar streams HLS, MPEG-TS, MP4, audio-only, reconexión y cambios rápidos de canal.
6. Añadir pruebas instrumentadas y generar APK release firmada por el usuario.

## Nota de marca
VLC es software libre de VideoLAN. Este proyecto es independiente y no oficial.
