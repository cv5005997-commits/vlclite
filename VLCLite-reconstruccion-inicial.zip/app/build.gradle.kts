plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.vlclite.player"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vlclite.player"
        minSdk = 21
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
        multiDexEnabled = false
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    // LibVLC is the upstream VLC multimedia engine; keep one playback engine, no Media3/ExoPlayer.
    implementation("org.videolan.android:libvlc-all:3.6.5")
}
