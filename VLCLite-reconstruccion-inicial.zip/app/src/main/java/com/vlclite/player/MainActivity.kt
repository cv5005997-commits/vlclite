package com.vlclite.player

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * VLC Lite - minimal native shell around upstream LibVLC.
 * Designed to avoid extra UI frameworks and duplicate playback engines.
 */
class MainActivity : Activity() {
    private var libVLC: LibVLC? = null
    private var player: MediaPlayer? = null
    private lateinit var video: VLCVideoLayout
    private lateinit var urlInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        initializePlayer()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF101010.toInt())
            isFocusableInTouchMode = true
        }
        val title = TextView(this).apply {
            text = "VLC Lite"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
        }
        urlInput = EditText(this).apply {
            hint = "URL HTTP / HTTPS / M3U8"
            setSingleLine(true)
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFAAAAAA.toInt())
            setSelectAllOnFocus(false)
        }
        val play = Button(this).apply {
            text = "REPRODUCIR"
            setOnClickListener { playUrl(urlInput.text.toString().trim()) }
        }
        status = TextView(this).apply {
            text = "Listo para reproducir"
            textSize = 12f
            setTextColor(0xFFCCCCCC.toInt())
        }
        video = VLCVideoLayout(this)
        root.addView(title)
        root.addView(urlInput)
        root.addView(play)
        root.addView(status)
        root.addView(video, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun initializePlayer() {
        try {
            // Conservative defaults: avoid unnecessary hardware decoder pressure.
            val options = arrayListOf(
                "--no-video-title-show",
                "--avcodec-threads=2",
                "--network-caching=1000",
                "--live-caching=1000",
                "--file-caching=1000",
                "--clock-jitter=0",
                "--drop-late-frames",
                "--skip-frames"
            )
            libVLC = LibVLC(this, options)
            player = MediaPlayer(libVLC).also {
                it.attachViews(video, null, false, false)
            }
        } catch (e: Exception) {
            status.text = "Error inicializando motor: ${e.message ?: "desconocido"}"
        }
    }

    private fun playUrl(url: String) {
        if (url.isBlank()) {
            Toast.makeText(this, "Ingresá una URL válida", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val media = Media(libVLC, android.net.Uri.parse(url)).apply {
                setHWDecoderEnabled(true, false)
                addOption(":http-reconnect")
                addOption(":network-caching=1000")
                addOption(":live-caching=1000")
            }
            player?.stop()
            player?.media = media
            media.release()
            player?.play()
            status.text = "Conectando…"
        } catch (e: Exception) {
            status.text = "No se pudo iniciar: ${e.message ?: "error"}"
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                player?.let { if (it.isPlaying) it.pause() else it.play() }
                return true
            }
            KeyEvent.KEYCODE_MEDIA_STOP -> { player?.stop(); return true }
            KeyEvent.KEYCODE_BACK -> {
                if (player?.isPlaying == true) { player?.stop(); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        player?.stop()
        player?.detachViews()
        player?.release()
        player = null
        libVLC?.release()
        libVLC = null
        super.onDestroy()
    }
}
